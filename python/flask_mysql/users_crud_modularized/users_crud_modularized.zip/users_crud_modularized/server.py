from flask_app.controllers import database_users
from flask_app import app




if __name__ == "__main__":
    app.run(debug=True)